package com.swq200.controller

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.*
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.swq200.controller.databinding.ActivityMainBinding
import java.text.SimpleDateFormat
import java.util.*

@SuppressLint("MissingPermission")
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val handler = Handler(Looper.getMainLooper())

    private var bluetoothManager: BluetoothManager? = null
    private var bluetoothAdapter: BluetoothAdapter? = null
    private var bluetoothGatt: BluetoothGatt? = null
    private var writeChar: BluetoothGattCharacteristic? = null
    private var notifyChar: BluetoothGattCharacteristic? = null

    private var isConnected = false
    private val rxBuffer = mutableListOf<Byte>()

    companion object {
        private const val TAG = "SWQ200"
        private const val REQUEST_PERMISSIONS = 1001
        private const val SCAN_PERIOD = 10000L
        private val UUID_CCCCD = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        bluetoothManager = getSystemService(BLUETOOTH_SERVICE) as BluetoothManager
        bluetoothAdapter = bluetoothManager?.adapter

        setupButtons()
        checkPermissions()
    }

    private fun setupButtons() {
        binding.btnConnect.setOnClickListener {
            if (isConnected) disconnectDevice() else scanAndConnect()
        }

        // 按键指令
        binding.btnRead.setOnClickListener { sendCmd("ATK001#") }
        binding.btnPlus.setOnClickListener { sendCmd("ATK002#") }
        binding.btnMenu.setOnClickListener { sendCmd("ATK003#") }
        binding.btnMinus.setOnClickListener { sendCmd("ATK004#") }
        binding.btnArea.setOnClickListener { sendCmd("ATK005#") }
        binding.btnLevel.setOnClickListener { sendCmd("ATK006#") }
        binding.btnPythagoras.setOnClickListener { sendCmd("ATK007#") }
        binding.btnTimer.setOnClickListener { sendCmd("ATK008#") }
        binding.btnClear.setOnClickListener { sendCmd("ATK009#") }
        binding.btnSave.setOnClickListener { sendCmd("ATK00A#") }

        // 查询指令
        binding.btnSysInfo.setOnClickListener { sendCmd("ATS001#") }
        binding.btnCurRecord.setOnClickListener { sendCmd("ATD001#") }
        binding.btnScreen.setOnClickListener { sendCmd("ATI001#") }

        binding.btnClearLog.setOnClickListener { binding.logText.text = "" }
    }

    // ===== 权限 =====
    private fun checkPermissions() {
        val perms = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            perms.add(Manifest.permission.BLUETOOTH_SCAN)
            perms.add(Manifest.permission.BLUETOOTH_CONNECT)
        } else {
            perms.add(Manifest.permission.ACCESS_FINE_LOCATION)
            perms.add(Manifest.permission.ACCESS_COARSE_LOCATION)
        }
        val needed = perms.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (needed.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, needed.toTypedArray(), REQUEST_PERMISSIONS)
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_PERMISSIONS) {
            if (grantResults.any { it != PackageManager.PERMISSION_GRANTED }) {
                log("权限被拒绝", true)
                Toast.makeText(this, "需要蓝牙和定位权限", Toast.LENGTH_LONG).show()
            }
        }
    }

    // ===== 扫描连接 =====
    private fun scanAndConnect() {
        val adapter = bluetoothAdapter
        if (adapter == null || !adapter.isEnabled) {
            log("请先打开蓝牙", true)
            return
        }

        log("正在扫描BLE设备...")
        binding.tvConn.text = "扫描中..."
        binding.tvConn.setTextColor(ContextCompat.getColor(this, R.color.warning))

        val scanner = adapter.bluetoothLeScanner
        val settings = ScanSettings.Builder()
            .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
            .build()

        scanner.startScan(null, settings, scanCallback)

        handler.postDelayed({
            scanner.stopScan(scanCallback)
            if (!isConnected) {
                binding.tvConn.text = "未连接"
                binding.tvConn.setTextColor(ContextCompat.getColor(this, R.color.text_dim))
            }
        }, SCAN_PERIOD)
    }

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            val name = result.device.name ?: return
            log("发现设备: $name")

            if (name.contains("SW", ignoreCase = true) ||
                name.contains("Q200", ignoreCase = true)
            ) {
                log("匹配到目标设备，连接中...")
                bluetoothAdapter?.bluetoothLeScanner?.stopScan(this)
                connectDevice(result.device)
            }
        }

        override fun onScanFailed(errorCode: Int) {
            log("扫描失败: $errorCode", true)
        }
    }

    private fun connectDevice(device: BluetoothDevice) {
        log("连接: ${device.name}")
        bluetoothGatt = device.connectGatt(this, false, gattCallback, BluetoothDevice.TRANSPORT_LE)
    }

    private fun disconnectDevice() {
        bluetoothGatt?.disconnect()
        bluetoothGatt?.close()
        bluetoothGatt = null
        isConnected = false
        writeChar = null
        notifyChar = null
        updateConnUI(false)
        log("已断开")
    }

    // ===== GATT 回调 =====
    private val gattCallback = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(gatt: BluetoothGatt, status: Int, newState: Int) {
            runOnUiThread {
                when (newState) {
                    BluetoothProfile.STATE_CONNECTED -> {
                        log("GATT已连接，发现服务...")
                        gatt.discoverServices()
                    }
                    BluetoothProfile.STATE_DISCONNECTED -> {
                        log("设备断开", true)
                        isConnected = false
                        updateConnUI(false)
                        writeChar = null
                        notifyChar = null
                    }
                }
            }
        }

        override fun onServicesDiscovered(gatt: BluetoothGatt, status: Int) {
            runOnUiThread {
                log("服务数量: ${gatt.services.size}")
                findChars(gatt)
            }
        }

        override fun onCharacteristicChanged(gatt: BluetoothGatt, ch: BluetoothGattCharacteristic) {
            runOnUiThread {
                ch.value?.let { onNotifyData(it) }
            }
        }
    }

    private fun findChars(gatt: BluetoothGatt) {
        for (service in gatt.services) {
            for (ch in service.characteristics) {
                val props = ch.properties
                if ((props and BluetoothGattCharacteristic.PROPERTY_WRITE > 0 ||
                            props and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE > 0)
                    && writeChar == null
                ) {
                    writeChar = ch
                    log("找到写特征")
                }
                if (props and BluetoothGattCharacteristic.PROPERTY_NOTIFY > 0
                    && notifyChar == null
                ) {
                    notifyChar = ch
                    log("找到通知特征")
                    gatt.setCharacteristicNotification(ch, true)
                    ch.getDescriptor(UUID_CCCCD)?.let { desc ->
                        desc.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
                        gatt.writeDescriptor(desc)
                    }
                }
            }
        }

        if (writeChar != null && notifyChar != null) {
            isConnected = true
            updateConnUI(true)
            log("===== 连接成功 =====")
            handler.postDelayed({ sendCmd("ATS001#") }, 500)
        } else {
            log("未找到完整通信特征", true)
        }
    }

    private fun updateConnUI(ok: Boolean) {
        runOnUiThread {
            if (ok) {
                binding.tvConn.text = "已连接"
                binding.tvConn.setTextColor(ContextCompat.getColor(this, R.color.primary))
                binding.btnConnect.text = "断开连接"
                binding.btnConnect.setBackgroundColor(ContextCompat.getColor(this, R.color.danger))
            } else {
                binding.tvConn.text = "未连接"
                binding.tvConn.setTextColor(ContextCompat.getColor(this, R.color.text_dim))
                binding.btnConnect.text = "连接蓝牙设备"
                binding.btnConnect.setBackgroundColor(ContextCompat.getColor(this, R.color.primary))
            }
        }
    }

    // ===== 发送指令 =====
    private fun sendCmd(cmd: String) {
        val ch = writeChar
        if (!isConnected || ch == null) {
            log("未连接: $cmd", true)
            return
        }
        ch.value = cmd.toByteArray(Charsets.US_ASCII)
        ch.writeType = if (ch.properties and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE > 0) {
            BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE
        } else {
            BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
        }
        bluetoothGatt?.writeCharacteristic(ch)
        log("→ 发送: $cmd")
    }

    // ===== 接收数据 =====
    private fun onNotifyData(data: ByteArray) {
        rxBuffer.addAll(data.toList())
        if (rxBuffer.size > 4096) {
            log("缓冲区溢出", true)
            rxBuffer.clear()
            return
        }
        while (rxBuffer.contains(0x23.toByte())) {
            val idx = rxBuffer.indexOf(0x23.toByte())
            val frame = rxBuffer.subList(0, idx + 1).toByteArray()
            rxBuffer.subList(0, idx + 1).clear()
            parseFrame(frame)
        }
    }

    private fun parseFrame(frame: ByteArray) {
        if (frame.size < 3) return
        val hex = frame.joinToString(" ") { "%02X".format(it) }
        log("← 接收: $hex")

        val b0 = frame[0].toInt() and 0xFF
        val b1 = frame[1].toInt() and 0xFF
        val b2 = frame[2].toInt() and 0xFF
        val header = "${b0.toChar()}${b1.toChar()}${b2.toChar()}"

        when (header) {
            "ATD" -> parseATD(frame)
            "ATI" -> parseATI(frame)
            else -> if (b0 == 0x2A && b1 == 0x2A) parseSysInfo(frame)
        }
    }

    private fun readInt32(frame: ByteArray, off: Int): Int {
        return (frame[off].toInt() and 0xFF) or
                ((frame[off+1].toInt() and 0xFF) shl 8) or
                ((frame[off+2].toInt() and 0xFF) shl 16) or
                ((frame[off+3].toInt() and 0xFF) shl 24)
    }

    private fun parseATD(frame: ByteArray) {
        if (frame.size < 14) { log("ATD长度不足", true); return }
        val distM = readInt32(frame, 3) / 1000.0
        val angX = readInt32(frame, 7) / 10.0
        val angY = readInt32(frame, 11) / 10.0

        binding.tvDist.text = String.format("%.2f", distM)
        binding.tvAngX.text = String.format("%.1f°", angX)
        binding.tvAngY.text = String.format("%.1f°", angY)
        log("距离: %.3fm  角度X: %.1f°  角度Y: %.1f°".format(distM, angX, angY))
    }

    private fun parseATI(frame: ByteArray) {
        if (frame.size < 15) { log("ATI长度不足", true); return }
        val d0 = readInt32(frame, 3) / 1000.0
        binding.tvDist.text = String.format("%.2f", d0)
        log("ATI主距离: %.3fm".format(d0))
    }

    private fun parseSysInfo(frame: ByteArray) {
        val off = 2
        if (frame.size < off + 12) { log("系统信息长度不足", true); return }
        val devId = "${frame[off].toInt() and 0xFF}.${frame[off+1].toInt() and 0xFF}"
        val saveQty = (frame[off+2].toInt() and 0xFF) or ((frame[off+3].toInt() and 0xFF) shl 8)
        log("设备ID: $devId  存储: $saveQty 条")
    }

    // ===== 日志 =====
    private fun log(msg: String, isErr: Boolean = false) {
        val time = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
        val color = if (isErr) "#ff5252" else "#9e9e9e"
        runOnUiThread {
            binding.logText.append("<font color='$color'>[$time] $msg</font><br>")
        }
        Log.d(TAG, msg)
    }

    override fun onDestroy() {
        super.onDestroy()
        disconnectDevice()
    }
}
